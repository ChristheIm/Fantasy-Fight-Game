#include <iostream>
#include "Gameplay.h"

using namespace std;

int main() {

	Gameplay play;
	play.playGame();

	return 0;
}